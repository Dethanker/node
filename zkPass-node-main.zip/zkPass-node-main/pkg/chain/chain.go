package chain

type Chain struct {
}
