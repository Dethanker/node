package keystore

type ZKP struct {
}
