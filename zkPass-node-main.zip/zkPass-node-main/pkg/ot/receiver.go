package ot

type Receiver struct {
}
