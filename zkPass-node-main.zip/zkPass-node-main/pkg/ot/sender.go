package ot

type Sender struct {
}
